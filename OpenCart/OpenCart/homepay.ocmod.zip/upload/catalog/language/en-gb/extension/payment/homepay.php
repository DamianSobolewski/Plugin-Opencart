<?php

// Heading
$_['heading_title'] = 'Homepay';

// Text
$_['text_title'] = 'Homepay';
$_['text_homepay_order'] = 'Order';
$_['text_homepay_discount'] = 'Discount';
$_['text_error_message'] = 'Something went wrong. You can not order by Homepay.';